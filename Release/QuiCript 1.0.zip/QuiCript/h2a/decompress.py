import zlib, os
from streamIO import StreamReader
from enum import Flag

def decompressor(data):
    stream = StreamReader(data)
    count = stream.readInt(4)
    flag = stream.readInt(4)

    offsets = [stream.readInt(8) for i in range(count)]
    offsets.append(len(data))

    with open("tmp", "wb") as file:
        for i in range(len(offsets) - 1):
            if flag:
                decomp = data[offsets[i] : offsets[i + 1]]
            else:
                decomp = zlib.decompress(data[offsets[i] : offsets[i + 1]])
            file.write(decomp)

    decompressed_data = open("tmp", "rb").read()

    os.remove("tmp")

    return decompressed_data
