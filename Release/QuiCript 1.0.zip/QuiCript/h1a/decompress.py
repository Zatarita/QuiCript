import zlib
import os

from streamIO import StreamReader

"""
    decompressor:
        Function to handle decompressing h1a files
            data: compressed data | or path
            return: decompressed data (surprising)
"""
def decompressor(data):
    # if data is actually a path
    if type(data) == str:
        data = open(data, "rb").read()

    stream = StreamReader(data)
    # read the chunk count
    count = stream.readInt(4)

    # read offsets
    offsets = [stream.readInt(4) + 4 for i in range(count)]
    # temporary offset to calculate last - end
    offsets.append(len(data))

    with open("tmp", "wb") as file:
        for i in range(len(offsets) - 1):
            test = data[offsets[i]:offsets[i + 1]]
            file.write(zlib.decompress(data[offsets[i]:offsets[i + 1]]))

    # read the buffer back
    with open("tmp", "rb") as file:
        decompressed_data = file.read()

    # cleanup
    os.remove("tmp")
    return decompressed_data
