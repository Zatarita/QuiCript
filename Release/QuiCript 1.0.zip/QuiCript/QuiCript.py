from h1a import *
from h2a import *

import sys
import os

POSSIBLE_ZLIB_HEADERS = [
    b"\x08\x1D", b"\x08\x5B", b"\x08\x99", b"\x08\xD7",
    b"\x18\x19", b"\x18\x57", b"\x18\x95", b"\x18\xD3",
    b"\x28\x15", b"\x28\x53", b"\x28\x91", b"\x28\xCf",
    b"\x38\x11", b"\x38\x4F", b"\x38\x8D", b"\x38\xCB",
    b"\x48\x0D", b"\x48\x4B", b"\x48\x89", b"\x48\xC7",
    b"\x58\x09", b"\x58\x47", b"\x58\x85", b"\x58\xC3",
    b"\x68\x05", b"\x68\x43", b"\x68\x81", b"\x68\xDE",
    b"\x78\x01", b"\x78\x5E", b"\x78\x9C", b"\x78\xDA",
    ]

def verify_compression(data, compress_type):
    if compress_type == "h1a":
        if len(data) < 0x40006:
            return False
        if data[0x40004:0x40006] not in POSSIBLE_ZLIB_HEADERS:
            return False

    if compress_type == "h2a":
        if len(data) < 0x600002:
            return False
        if data[0x600000:0x600002] not in POSSIBLE_ZLIB_HEADERS:
            return False
        
    return True

def init_QuiCript():
    # verify we have enough arguments
    if len(sys.argv) < 4:
        print("QuiCript 'h1a'/'h2a' -c/-d 'path/to/file' ... 'path/to/third/file' ")
        return

    # get system variables
    compression_type = sys.argv[1]
    compress = sys.argv[2]
    paths = sys.argv[3:]

    while compression_type not in ["h1a", "h2a"]:
        os.system("cls")
        compression_type = input("Unable to determine compression type: \n\th1a\n\th2a\n\n>")

    if compress not in ["-d", "-c"]:
        return

    for file in paths:
        if os.path.isdir(file): # if it is actually a folder
            continue

        data = open(file, "rb").read()
        
        if compress == "-d":
            if not verify_compression(data, compression_type):
                print("File failed integrity test")
                break

            
        
        if compression_type == "h1a":
            if compress == "-c":
                print("Compressing: " + file.split("/")[-1] + " with h1a compression")
                open(file + "_tmp", "wb").write(h1a_compress(data))
                os.remove(file) #save to a temp file as to not overwrite original if failed
                os.rename(file + "_tmp", file)
            if compress == "-d":
                print("Decompressing: " + file.split("/")[-1] + " with h1a compression")
                open(file + "_tmp", "wb").write(h1a_decompress(data))
                os.remove(file)
                os.rename(file + "_tmp", file)
        elif compression_type == "h2a":
            if compress == "-c":
                print("Compressing: " + file.split("/")[-1] + " with h2a compression")
                open(file + "_tmp", "wb").write(h2a_compress(data))
                os.remove(file)
                os.rename(file + "_tmp", file)
            if compress == "-d":
                print("Decompressing: " + file.split("/")[-1] + " with h2a compression")
                open(file + "_tmp", "wb").write(h2a_decompress(data))
                os.remove(file)
                os.rename(file + "_tmp", file)

init_QuiCript()
