from .compress import compressor as h1a_compress
from .decompress import decompressor as h1a_decompress