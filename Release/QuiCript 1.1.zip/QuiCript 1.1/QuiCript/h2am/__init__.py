from .compress import compressor as h2am_compress
from .decompress import decompressor as h2am_decompress