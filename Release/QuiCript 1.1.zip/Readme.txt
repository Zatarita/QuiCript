This program was developed by Zatarita.
It requires Python.

QuiCript can be used on its own if desired. Extract QuiCript folder to somewhere you want to use it, and just call 'python QuiCript.py'

usage is as follows:
'python QuiCript.py 'h1a'/'h2a'/'h2am' -c/-d 'path/to/file' ... 'path/to/third/file'

h1a  - Halo 1 Anniversary Compression
h2a  - Halo 2 Anniversary Compression
h2am - Halo 2 Anniversary Compression Map File Variant